import { io } from "socket.io-client";

// Configuração da conexão com o servidor WebSocket
export const socket = io("http://172.29.163.109:3001", {
  reconnection: true, // Habilita a tentativa automática de reconexão
  reconnectionAttempts: 10, // Define o número máximo de tentativas de reconexão
  reconnectionDelay: 5000, // Tempo (em ms) entre as tentativas de reconexão
});

const subscribedLines = new Set(); // Conjunto para rastrear as linhas inscritas

// Função para se inscrever em uma linha específica no WebSocket
export const subscribeToLine = (line) => {
  if (socket.connected) {
    // Se já estiver conectado, podemos inscrever imediatamente
    socket.emit("subscribe", line);
    subscribedLines.add(line);
    console.log(
      `Inscrito nos tópicos: productiondata/${line} e shiftdata/${line}`
    );
  } else {
    // Se não estiver conectado, tentamos reconectar e inscrever assim que possível
    console.log("WebSocket não conectado. Tentando reconectar...");
    socket.once("connect", () => {
      console.log("Conectado ao WebSocket após reconexão.");
      socket.emit("subscribe", line);
      subscribedLines.add(line);
      console.log(
        `Inscrito nos tópicos após reconexão: productiondata/${line} e shiftdata/${line}`
      );
    });
  }
};

// Função para cancelar a inscrição de uma linha no WebSocket
export const unsubscribeFromLine = (line) => {
  socket.emit("unsubscribe", line);
  subscribedLines.delete(line);
  console.log(`Desinscrito do tópico: productiondata/${line}`);
};

// Função para reinscrever todas as linhas após uma reconexão do WebSocket
const resubscribeToAllLines = () => {
  subscribedLines.forEach((line) => {
    console.log(`Reinscrevendo na linha: ${line}`);
    subscribeToLine(line);
  });
};

// Evento acionado ao conectar/reconectar ao WebSocket
socket.on("connect", () => {
  console.log("Reconectado ao WebSocket! Reinscrevendo nas linhas...");
  resubscribeToAllLines();
});

// Função para ouvir mensagens de produção de uma linha específica
export const listenToProductionData = (line, callback) => {
  const topic = `productiondata/${line}`;
  socket.on(topic, (data) => {
    callback(data);
  });
};

// Função para ouvir dados de turno de uma linha específica
export const listenToShiftData = (line, callback) => {
  const topic = `shiftdata/${line}`;
  socket.on(topic, (data) => {
    callback(data);
  });
};

// Função para ouvir informações do turno atual
export const listenActualShiftInfo = (callback) => {
  const topic = "actualshift/";
  socket.on(topic, (data) => {
    callback(data);
  });
};

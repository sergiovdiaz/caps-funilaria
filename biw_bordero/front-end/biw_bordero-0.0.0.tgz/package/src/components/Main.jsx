import React, { useState } from "react";
import ItemList from "./ItemList";

const Main = () => {
  // Estado único para gerenciar visibilidade de todos os grupos
  const [sideBySideOpen, setSideBySideOpen] = useState({
    1: true, // LATERAL DIREITA e LATERAL ESQUERDA
    2: true, // TETO, CAPO e PARALAMA
    3: true, // PORTA MALA e UTE 3
  });

  // Função genérica para alternar a visibilidade de um grupo
  const toggleVisibility = (group) => {
    setSideBySideOpen((prev) => ({
      ...prev,
      [group]: !prev[group],
    }));
  };

  return (
    <div className="main">
      <ItemList title="CARROCERIA" />
      <ItemList title="SOTTO GRUPPO" />

      <div className="main__side-by-side">
        <ItemList
          title="LATERAL ESQUERDA"
          isSideBySide
          isOpen={sideBySideOpen[1]}
          toggleVisibility={() => toggleVisibility(1)}
        />
        <ItemList
          title="LATERAL DIREITA"
          isSideBySide
          isOpen={sideBySideOpen[1]}
          toggleVisibility={() => toggleVisibility(1)}
        />
      </div>

      <ItemList title="PORTAS" />

      <div className="main__side-by-side">
        <ItemList
          title="PORTA MALA"
          isSideBySide
          isOpen={sideBySideOpen[3]}
          toggleVisibility={() => toggleVisibility(3)}
        />
        <ItemList
          title="UTE 3"
          isSideBySide
          isOpen={sideBySideOpen[3]}
          toggleVisibility={() => toggleVisibility(3)}
        />
      </div>

      <div className="main__side-by-side">
        <ItemList
          title="TETO"
          isSideBySide
          isOpen={sideBySideOpen[2]}
          toggleVisibility={() => toggleVisibility(2)}
        />
        <ItemList
          title="CAPO"
          isSideBySide
          isOpen={sideBySideOpen[2]}
          toggleVisibility={() => toggleVisibility(2)}
        />
        <ItemList
          title="PARALAMA"
          isSideBySide
          isOpen={sideBySideOpen[2]}
          toggleVisibility={() => toggleVisibility(2)}
        />
      </div>
    </div>
  );
};

export default Main;

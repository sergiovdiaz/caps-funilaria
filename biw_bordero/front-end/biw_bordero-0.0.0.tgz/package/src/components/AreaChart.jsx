import React from "react";
import Chart from "react-apexcharts";
import moment from "moment-timezone";

const AreaChart = ({ line, series, info }) => {
  const maxY = series[0]?.data
    ? Math.max(6, ...series[0].data.map((item) => item.y))
    : 6;

  const options = {
    chart: {
      id: "basic-area",
      toolbar: {
        show: true,
        tools: {
          zoomin: true,
          zoomout: true,
          reset: true,
        },
        export: {
          csv: true,
          svg: true,
        },
      },
      zoom: {
        enabled: true,
        allowMouseWheelZoom: false,
      },
    },
    title: {
      text: line || "",
      align: "left",
      margin: 20,
      style: {
        fontSize: "14px",
        fontWeight: "bold",
        fontFamily: "Arial, sans-serif",
      },
    },
    dataLabels: {
      enabled: true, // Habilitar dataLabels para todos os pontos
      formatter: (val, opts) => {
        // Verifica se é o último ponto e exibe o valor
        if (
          opts.seriesIndex === 0 &&
          opts.dataPointIndex === series[0]?.data.length - 1
        ) {
          return `${val}`; // Exibe o valor do último ponto
        }
        return undefined; // Para os outros pontos, não exibe nada
      },
    },
    tooltip: {
      enabled: true,
      shared: true,
      intersect: false,
      x: {
        format: "HH:mm", // Exibe a hora no formato HH:mm
      },
    },
    xaxis: {
      // type: "datetime",
      labels: {
        formatter: function (value) {
          // Converte o timestamp para o fuso horário UTC-3
          return moment(value).tz("America/Recife").format("HH:mm");
        },
        rotate: 0, // Rotaciona os labels para que fiquem horizontais
      },
      tickAmount: 2,
      max: 13,
    },
    yaxis: {
      // forceNiceScale: true,
      max: maxY, // Definindo o máximo do eixo Y dinamicamente
      min: 0,
      labels: {
        formatter: function (value) {
          return Math.floor(value); // Garante que os valores do eixo Y sejam inteiros
        },
      },
    },
  };

  return (
    <div className="areachart" style={{ position: "relative" }}>
      <Chart options={options} series={series} type="area" width="250" />

      <div className="areachart__infobox">
        <div className="areachart__infobox-item">
          <span className="areachart__infobox-value">{info.producaoTurno}</span>
          <span className="areachart__infobox-label">Produção/turno</span>
        </div>
        <div className="areachart__infobox-item">
          <span className="areachart__infobox-value">{info.velocidade}</span>
          <span className="areachart__infobox-label">JPH</span>
        </div>
        <div className="areachart__infobox-item">
          <span className="areachart__infobox-value">{info.tempoCiclo}</span>
          <span className="areachart__infobox-label">Tempo Ciclo</span>
        </div>
      </div>
    </div>
  );
};

export default AreaChart;

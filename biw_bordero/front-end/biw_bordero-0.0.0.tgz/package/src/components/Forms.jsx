import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  horariosPorTurno,
  uteLinhas,
  linhasInfo,
} from "../assets/database/infoforms";
import FormsPerda from "./FormsPerda"; // Importando o FormsPerda

const Forms = () => {
  const { register, handleSubmit, control, watch } = useForm({
    defaultValues: {
      date: new Date(),
      turno: "1T",
      horario: "",
      ute: 1,
      linha: "",
      producaoReal: "",
    },
  });

  const [linhasDoUte, setLinhasDoUte] = useState([]);
  const [producaoHora, setProducaoHora] = useState(null);
  const [delta, setDelta] = useState(null);
  const [showFormPerda, setShowFormPerda] = useState(false);
  const [totalPerda, setTotalPerda] = useState(0); // Estado para armazenar a soma das perdas

  const turnoSelecionado = watch("turno");
  const uteSelecionado = watch("ute");
  const linhaSelecionadaValor = watch("linha");

  const onSubmit = (data) => {
    console.log("Dados selecionados:", data);
  };

  useEffect(() => {
    console.log("UTE Selecionado:", uteSelecionado);
    const linhas =
      uteLinhas.find((item) => item.ute === parseInt(uteSelecionado))?.linhas ||
      [];
    setLinhasDoUte(linhas);
  }, [uteSelecionado]);

  useEffect(() => {
    if (linhaSelecionadaValor) {
      const linhaInfo = linhasInfo.find(
        (linha) => linha.nome === linhaSelecionadaValor
      );
      if (linhaInfo) {
        setProducaoHora(linhaInfo.producao_hora);
        setDelta(null); // Resetando delta ao mudar a linha
      }
    }
  }, [linhaSelecionadaValor]);

  const handleProducaoRealChange = (e) => {
    const producaoReal = e.target.value;
    setDelta(producaoHora - producaoReal);
  };

  const handleAddPerda = () => {
    setShowFormPerda(true); // Exibe o FormsPerda ao clicar no botão
  };

  // Função para adicionar a perda calculada ao totalPerda
  const handlePerdaCalculada = (perda) => {
    setTotalPerda((prevTotal) => prevTotal + perda);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="bg-white shadow-lg rounded-xl p-6 w-full max-w-md">
        <h2 className="text-xl font-bold mb-4 text-center">
          Selecionar Data e Turno
        </h2>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* DatePicker */}
          <div>
            <label className="block font-medium">Data</label>
            <Controller
              control={control}
              name="date"
              render={({ field }) => (
                <DatePicker
                  {...field}
                  selected={field.value}
                  onChange={(date) => field.onChange(date)}
                  className="w-full p-2 border rounded-md"
                  dateFormat="dd/MM/yyyy"
                />
              )}
            />
          </div>

          {/* Dropdown Turno */}
          <div>
            <label className="block font-medium">Turno</label>
            <select
              {...register("turno")}
              className="w-full p-2 border rounded-md"
            >
              <option value="1T">1º Turno</option>
              <option value="2T">2º Turno</option>
              <option value="3T">3º Turno</option>
            </select>
          </div>

          {/* Dropdown Horários */}
          <div>
            <label className="block font-medium">Horário</label>
            <select
              {...register("horario")}
              className="w-full p-2 border rounded-md"
            >
              {horariosPorTurno[turnoSelecionado]?.map((horario, index) => (
                <option key={index} value={horario}>
                  {horario}
                </option>
              ))}
            </select>
          </div>

          {/* Dropdown UTE */}
          <div>
            <label className="block font-medium">UTE</label>
            <select
              {...register("ute")}
              className="w-full p-2 border rounded-md"
            >
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
            </select>
          </div>

          {/* Dropdown Linha */}
          <div>
            <label className="block font-medium">Linha</label>
            <select
              {...register("linha")}
              className="w-full p-2 border rounded-md"
            >
              {linhasDoUte.map((linha, index) => (
                <option key={index} value={linha}>
                  {linha}
                </option>
              ))}
            </select>
          </div>

          {/* Exibindo a Produção Hora e Input de Produção Real */}
          {producaoHora && (
            <div className="mt-4">
              <div>
                <label className="block font-medium">
                  Produção Planejada (hora)
                </label>
                <p className="text-lg">{producaoHora}</p>
              </div>

              <div>
                <label className="block font-medium">Produção Real</label>
                <input
                  type="number"
                  {...register("producaoReal")}
                  onChange={handleProducaoRealChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="Digite a produção real"
                />
              </div>

              {/* Exibindo o Delta */}
              {delta !== null && (
                <div className="mt-2">
                  <label className="block font-medium">Delta</label>
                  <p className="text-lg">{delta}</p>
                </div>
              )}
            </div>
          )}

          {/* Botão de Enviar */}
          <button
            type="submit"
            className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600"
          >
            Confirmar Seleção
          </button>

          {/* Botão Adicionar Perda */}
          {delta !== null && (
            <button
              type="button"
              onClick={handleAddPerda}
              className="w-full mt-4 bg-green-500 text-white p-2 rounded-md hover:bg-green-600"
            >
              Adicionar Perda
            </button>
          )}
        </form>

        {/* Exibindo a soma das perdas */}
        <div className="mt-4">
          <h3 className="text-xl">Total Perda Calculada: {totalPerda}</h3>
        </div>
      </div>

      {/* Exibindo o FormsPerda quando o botão for clicado */}
      {showFormPerda && (
        <FormsPerda
          linhaSelecionada={linhaSelecionadaValor}
          delta={delta}
          onPerdaCalculada={handlePerdaCalculada}
        />
      )}
    </div>
  );
};

export default Forms;

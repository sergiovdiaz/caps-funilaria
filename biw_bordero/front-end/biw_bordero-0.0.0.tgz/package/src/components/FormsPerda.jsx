import React, { useState, useEffect } from "react";
import { linhasInfo } from "../assets/database/infoforms";

const FormsPerda = ({ linhaSelecionada }) => {
  const [horaInicial, setHoraInicial] = useState("");
  const [horaFinal, setHoraFinal] = useState("");
  const [perda, setPerda] = useState(0);

  const [tcLinha, setTcLinha] = useState(null);

  // Estados para os novos campos
  const [descricao, setDescricao] = useState("");
  const [grupoDePerdas, setGrupoDePerdas] = useState("");
  const [responsavel, setResponsavel] = useState("");

  // Usando useEffect para definir o TC da linha selecionada
  useEffect(() => {
    if (linhaSelecionada) {
      const linhaInfo = linhasInfo.find(
        (linha) => linha.nome === linhaSelecionada
      );
      setTcLinha(linhaInfo ? linhaInfo.TC : null);
    }
  }, [linhaSelecionada]);

  // Função para calcular a perda automaticamente
  useEffect(() => {
    if (horaInicial && horaFinal && tcLinha) {
      const horaInicialDate = new Date(`1970-01-01T${horaInicial}:00`);
      const horaFinalDate = new Date(`1970-01-01T${horaFinal}:00`);

      // Calculando a diferença em segundos
      const diffEmSegundos = (horaFinalDate - horaInicialDate) / 1000;

      // Calculando a perda com base no TC da linha
      const perdaCalculada = diffEmSegundos / tcLinha;
      setPerda(perdaCalculada);
    }
  }, [horaInicial, horaFinal, tcLinha]);

  return (
    <div className="bg-white shadow-lg rounded-xl p-6 w-full max-w-md mt-6">
      <h3 className="text-xl font-bold mb-4">Registrar Perda</h3>

      <div className="space-y-4">
        {/* Hora Inicial */}
        <div>
          <label className="block font-medium">Hora Inicial</label>
          <input
            type="time"
            value={horaInicial}
            onChange={(e) => setHoraInicial(e.target.value)}
            className="w-full p-2 border rounded-md"
          />
        </div>

        {/* Hora Final */}
        <div>
          <label className="block font-medium">Hora Final</label>
          <input
            type="time"
            value={horaFinal}
            onChange={(e) => setHoraFinal(e.target.value)}
            className="w-full p-2 border rounded-md"
          />
        </div>

        {/* Perda Calculada */}
        <div>
          <label className="block font-medium">
            Perda Calculada (segundos)
          </label>
          <input
            type="number"
            value={perda}
            readOnly
            className="w-full p-2 border rounded-md bg-gray-100"
          />
        </div>

        {/* Descrição */}
        <div>
          <label className="block font-medium">Descrição</label>
          <textarea
            value={descricao}
            onChange={(e) => setDescricao(e.target.value)}
            rows="4"
            className="w-full p-2 border rounded-md"
            placeholder="Descreva o ocorrido..."
          />
        </div>

        {/* Grupo de Perdas */}
        <div>
          <label className="block font-medium">Grupo de Perdas</label>
          <input
            type="text"
            value={grupoDePerdas}
            onChange={(e) => setGrupoDePerdas(e.target.value)}
            className="w-full p-2 border rounded-md"
            placeholder="Ex: Manutenção, Parada Programada..."
          />
        </div>

        {/* Responsável */}
        <div>
          <label className="block font-medium">Responsável</label>
          <input
            type="text"
            value={responsavel}
            onChange={(e) => setResponsavel(e.target.value)}
            className="w-full p-2 border rounded-md"
            placeholder="Nome do responsável"
          />
        </div>
      </div>
    </div>
  );
};

export default FormsPerda;

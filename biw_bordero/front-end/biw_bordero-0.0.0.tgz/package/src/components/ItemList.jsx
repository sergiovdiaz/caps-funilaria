import React, { useState, useEffect, useCallback, useRef } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import {
  socket,
  subscribeToLine,
  unsubscribeFromLine,
  listenToProductionData,
  listenToShiftData,
  listenActualShiftInfo,
} from "../../api/api";
import { biwLinesArray } from "../assets/database/biwLines";
import AreaChart from "./AreaChart";

const ItemList = ({ title, isSideBySide, isOpen, toggleVisibility }) => {
  const [lineData, setLineData] = useState({}); // Dados de produção
  const [shiftData, setShiftData] = useState({}); // Dados de turno
  const [localIsOpen, setLocalIsOpen] = useState(true); // Controle da visibilidade local
  const [actualShiftInfo, setActualShiftInfo] = useState({}); // Dados do turno atual
  const [shiftDataForActualShift, setShiftDataForActualShift] = useState({}); // Dados do ShiftData filtrados por linha

  const [actualShift, setActualShift] = useState(null); // Variável para armazenar o número do turno atual
  const subscribedLinesRef = useRef(new Set()); // Evita re-renderizações desnecessárias

  const fetchAndUpdateActualShift = useCallback(() => {
    listenActualShiftInfo((data) => {
      setActualShift(data.ActualShift); // Atualiza o turno atual
      setActualShiftInfo(data); // Armazena os dados do turno
    });
  }, []);

  // Função para buscar dados de uma linha específica
  const fetchAndUpdateLineData = useCallback(
    (line) => {
      if (socket.connected) {
        // Verificar se o WebSocket está conectado
        if (!subscribedLinesRef.current.has(line)) {
          subscribedLinesRef.current.add(line);
          subscribeToLine(line);

          listenToProductionData(line, (data) => {
            setLineData((prevData) => ({ ...prevData, [line]: data }));
          });

          listenToShiftData(line, (data) => {
            setShiftData((prevShiftData) => ({
              ...prevShiftData,
              [line]: data,
            }));

            if (actualShift && data.length > 0 && data[0][actualShift]) {
              setShiftDataForActualShift((prev) => ({
                ...prev,
                [line]: data[0][actualShift],
              }));
            }
          });
        }
      } else {
        console.log("WebSocket não conectado ainda, aguardando reconexão...");
      }
    },
    [actualShift]
  );

  useEffect(() => {
    // Buscar turno atual antes de carregar os dados das linhas
    fetchAndUpdateActualShift();

    const linesInGroup = biwLinesArray.filter((line) => line.group === title);

    // Verificar se o WebSocket está conectado antes de tentar inscrever
    if (socket.connected) {
      linesInGroup.forEach((line) => fetchAndUpdateLineData(line.line));
    } else {
      // Aguarda a reconexão e só depois chama a inscrição nos tópicos
      socket.once("connect", () => {
        linesInGroup.forEach((line) => fetchAndUpdateLineData(line.line));
      });
    }

    return () => {
      linesInGroup.forEach((line) => {
        if (subscribedLinesRef.current.has(line.line)) {
          unsubscribeFromLine(line.line);
          subscribedLinesRef.current.delete(line.line);
        }
      });
    };
  }, [title, fetchAndUpdateActualShift, fetchAndUpdateLineData]);

  const toggleLocalVisibility = () => {
    setLocalIsOpen((prev) => !prev);
  };

  return (
    <div className="item-list">
      <div
        className="item-list__header"
        onClick={isSideBySide ? toggleVisibility : toggleLocalVisibility}
        style={{ cursor: "pointer" }}
      >
        <div className="item-list__header-icon">
          {(isSideBySide ? isOpen : localIsOpen) ? (
            <ChevronDown size={22} />
          ) : (
            <ChevronRight size={22} />
          )}
        </div>
        <h2 style={{ display: "inline", marginLeft: "8px" }}>{title}</h2>
      </div>

      {(isSideBySide ? isOpen : localIsOpen) && (
        <div className="item-list__charts">
          {biwLinesArray
            .filter((line) => line.group === title)
            .map((line) => (
              <AreaChart
                key={line.line}
                line={line.line}
                series={lineData[line.line] || []}
                info={{
                  producaoTurno: shiftDataForActualShift[line.line]
                    ? shiftDataForActualShift[line.line].Production
                    : 0,
                  velocidade:
                    shiftDataForActualShift[line.line] &&
                    typeof shiftDataForActualShift[line.line].LineSpeed ===
                      "number"
                      ? shiftDataForActualShift[line.line].LineSpeed.toFixed(1)
                      : "N/A",
                  tempoCiclo: shiftDataForActualShift[line.line]
                    ? "N/A"
                    : "N/A",
                }}
              />
            ))}
        </div>
      )}
    </div>
  );
};

export default ItemList;

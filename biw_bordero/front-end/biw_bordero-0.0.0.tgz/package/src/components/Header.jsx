import React from "react";
import logoStellantis from "../assets/images/stellantis-icon.png";

const Header = () => {
  return (
    <div className="header">
      <img
        className="header__icon"
        src={logoStellantis}
        alt="Logo Stellantis"
      />
      <h1 className="header__title">Borderô</h1>
    </div>
  );
};

export default Header;

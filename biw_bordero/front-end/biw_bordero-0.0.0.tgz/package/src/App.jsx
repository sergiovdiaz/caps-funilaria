import React from "react";
import Header from "./components/Header";
import Main from "./components/Main";
import Forms from "./components/Forms";

const App = () => {
  return (
    <>
      <Header />
      <Main />
      {/* <Forms /> */}
    </>
  );
};

export default App;
